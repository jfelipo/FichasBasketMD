import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

type ConvertInput = z.infer<typeof api.convert.input>;
type ConvertResponse = z.infer<typeof api.convert.responses[200]>;
type StandingsInput = z.infer<typeof api.standings.input>;
type StandingsResponse = z.infer<typeof api.standings.responses[200]>;

export function useConvertUrl() {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: ConvertInput) => {
      const validatedInput = api.convert.input.parse(data);
      
      const res = await fetch(api.convert.path, {
        method: api.convert.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validatedInput),
        credentials: "include",
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || "Error converting URL");
      }

      const json = await res.json();
      return api.convert.responses[200].parse(json);
    },
    onError: (error) => {
      toast({
        title: "Error en la conversión",
        description: error.message,
        variant: "destructive",
      });
    },
    onSuccess: () => {
      toast({
        title: "Conversión exitosa",
        description: "El XML se ha generado correctamente.",
        variant: "default", 
        className: "bg-green-600 text-white border-none",
      });
    },
  });
}

export function useConvertStandings() {
  const { toast } = useToast();

  return useMutation<StandingsResponse, Error, StandingsInput>({
    mutationFn: async (data) => {
      const validatedInput = api.standings.input.parse(data);
      const response = await fetch(api.standings.path, {
        method: api.standings.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validatedInput),
        credentials: "include",
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || "Error al convertir la clasificación.");
      }

      return api.standings.responses[200].parse(await response.json());
    },
    onError: (error) => {
      toast({
        title: "Error en la conversión",
        description: error.message,
        variant: "destructive",
      });
    },
    onSuccess: () => {
      toast({
        title: "Conversión exitosa",
        description: "El XML de la clasificación se ha generado correctamente.",
        variant: "default",
        className: "bg-green-600 text-white border-none",
      });
    },
  });
}
