import { useState } from "react";
import { useConvertStandings, useConvertUrl } from "@/hooks/use-conversion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, Check, Copy, FileCode, Loader2, Sparkles, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const [mode, setMode] = useState<"gameday" | "standings">("gameday");
  const [gameday, setGameday] = useState(22);
  const [standingsText, setStandingsText] = useState("");
  const [format, setFormat] = useState<'ELBR' | 'ELBP'>('ELBR');
  const [xmlResult, setXmlResult] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  
  const { mutate: convert, isPending } = useConvertUrl();
  const {
    mutate: convertStandings,
    isPending: isStandingsPending,
  } = useConvertStandings();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gameday || gameday < 1 || gameday > 38) return;

    setXmlResult(null);
    setIsCopied(false);
    convert(
      { gameday, format },
      {
        onSuccess: (data) => {
          setXmlResult(data.xml);
        },
      }
    );
  };

  const handleStandingsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!standingsText.trim()) return;

    setXmlResult(null);
    setIsCopied(false);
    convertStandings(
      { text: standingsText },
      {
        onSuccess: (data) => {
          setXmlResult(data.xml);
        },
      },
    );
  };

  const selectMode = (nextMode: "gameday" | "standings") => {
    setMode(nextMode);
    setXmlResult(null);
    setIsCopied(false);
  };

  const copyToClipboard = async () => {
    if (!xmlResult) return;
    try {
      await navigator.clipboard.writeText(xmlResult);
      setIsCopied(true);
      toast({
        title: "Copiado",
        description: "El código XML se ha copiado al portapapeles.",
      });
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Error",
        description: "No se pudo copiar al portapapeles.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8 font-sans">
      
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-3xl text-center mb-10 space-y-4"
      >
        <div className="inline-flex items-center justify-center p-3 bg-white dark:bg-slate-800 rounded-2xl shadow-sm mb-4">
          <div className="bg-primary/10 p-2 rounded-xl">
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
          Conversor Euroliga a XML
        </h1>
        <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
          {mode === "gameday"
            ? "Genera automáticamente el fichero XML de la jornada a partir de los datos oficiales de la Euroliga."
            : "Convierte el texto de la clasificación en un documento XML listo para usar."}
        </p>
      </motion.div>

      <div className="mb-6 flex w-full max-w-3xl gap-2 rounded-xl bg-white/70 p-1.5 shadow-sm ring-1 ring-slate-900/5 dark:bg-slate-800/70 dark:ring-slate-100/5">
        <Button
          type="button"
          variant="outline"
          aria-pressed={mode === "gameday"}
          onClick={() => selectMode("gameday")}
          className={`h-11 flex-1 rounded-lg border-0 font-semibold transition-colors ${
            mode === "gameday"
              ? "bg-orange-600 text-white shadow-sm hover:bg-orange-700 hover:text-white"
              : "bg-transparent text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700"
          }`}
        >
          Jornadas
        </Button>
        <Button
          type="button"
          variant="outline"
          aria-pressed={mode === "standings"}
          onClick={() => selectMode("standings")}
          className={`h-11 flex-1 rounded-lg border-0 font-semibold transition-colors ${
            mode === "standings"
              ? "bg-orange-600 text-white shadow-sm hover:bg-orange-700 hover:text-white"
              : "bg-transparent text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700"
          }`}
        >
          Clasificación
        </Button>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="w-full max-w-3xl"
      >
        <Card className="border-0 shadow-xl bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm overflow-hidden ring-1 ring-slate-900/5 dark:ring-slate-100/5">
          <div className="h-2 bg-gradient-to-r from-orange-500 via-red-500 to-orange-600 w-full" />
          
          <CardHeader className="pb-8 pt-8 px-8">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <FileCode className="w-5 h-5 text-slate-500 dark:text-slate-400" />
              {mode === "gameday" ? "Configuración de Entrada" : "Conversión de clasificación"}
            </CardTitle>
            <CardDescription className="text-slate-500 dark:text-slate-400 text-base">
              {mode === "gameday"
                ? "Introduce el número de jornada (1-38) para obtener los resultados."
                : "Pega los datos de clasificación para generar el XML."}
            </CardDescription>
          </CardHeader>

          <CardContent className="px-8 pb-10 space-y-8">
            {mode === "gameday" ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="gameday" className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Número de Jornada
                </Label>
                <div className="relative group">
                  <Input
                    id="gameday"
                    data-testid="input-gameday"
                    type="number"
                    min={1}
                    max={38}
                    placeholder="22"
                    value={gameday}
                    onChange={(e) => setGameday(Number(e.target.value))}
                    className="h-14 pl-4 pr-4 rounded-xl border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-200 text-base shadow-sm group-hover:bg-white dark:group-hover:bg-slate-600"
                  />
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Temporada 2026-2027: Jornadas 1 a 38
                </p>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Formato XML
                </Label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="format"
                      data-testid="radio-elbr"
                      value="ELBR"
                      checked={format === 'ELBR'}
                      onChange={() => setFormat('ELBR')}
                      className="w-4 h-4 text-orange-600 focus:ring-orange-500"
                    />
                    <span className="text-sm text-slate-700 dark:text-slate-300">ELBR (Resultados)</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="format"
                      data-testid="radio-elbp"
                      value="ELBP"
                      checked={format === 'ELBP'}
                      onChange={() => setFormat('ELBP')}
                      className="w-4 h-4 text-orange-600 focus:ring-orange-500"
                    />
                    <span className="text-sm text-slate-700 dark:text-slate-300">ELBP (Próxima jornada)</span>
                  </label>
                </div>
              </div>

              <Button 
                type="submit" 
                data-testid="button-convert"
                disabled={isPending || !gameday || gameday < 1 || gameday > 38}
                className="w-full h-14 text-base font-semibold rounded-xl bg-orange-600 hover:bg-orange-700 shadow-lg shadow-orange-600/25 hover:shadow-xl hover:shadow-orange-600/30 transition-all duration-300 active:scale-[0.99]"
              >
                {isPending ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Procesando datos...
                  </>
                ) : (
                  <>
                    Convertir a XML
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </>
                )}
              </Button>
            </form>
            ) : (
              <form onSubmit={handleStandingsSubmit} className="space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <Label htmlFor="standings-text" className="text-sm font-medium text-slate-700 dark:text-slate-300">
                      Datos de clasificación
                    </Label>
                    {standingsText && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setStandingsText("");
                          setXmlResult(null);
                          setIsCopied(false);
                        }}
                        className="text-slate-500 hover:text-red-600 dark:text-slate-400"
                      >
                        <Trash2 className="mr-1.5 h-4 w-4" />
                        Limpiar
                      </Button>
                    )}
                  </div>
                  <Textarea
                    id="standings-text"
                    data-testid="textarea-standings"
                    value={standingsText}
                    onChange={(e) => setStandingsText(e.target.value)}
                    placeholder={"Pega aquí el texto sin formato…\n\nEjemplo:\n1\nFBB logo\nFenerbahce Beko Istanbul\n28 21 7 75% 2310 2217"}
                    className="min-h-[280px] w-full resize-y rounded-xl border-slate-200 bg-slate-50 p-4 font-mono text-sm leading-relaxed text-slate-900 placeholder:text-slate-400 dark:border-slate-600 dark:bg-slate-700 dark:text-slate-100"
                  />
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Se leen la posición, el nombre del equipo y sus estadísticas. Puedes pegar varios equipos seguidos.
                  </p>
                </div>
                <Button
                  type="submit"
                  data-testid="button-convert-standings"
                  disabled={isStandingsPending || !standingsText.trim()}
                  className="w-full h-14 text-base font-semibold rounded-xl bg-orange-600 hover:bg-orange-700 shadow-lg shadow-orange-600/25 transition-all duration-300"
                >
                  {isStandingsPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Procesando datos...
                    </>
                  ) : (
                    <>
                      Convertir clasificación a XML
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </>
                  )}
                </Button>
              </form>
            )}

            <AnimatePresence mode="wait">
              {xmlResult && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4 pt-6 border-t border-slate-100 dark:border-slate-700"
                >
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <Label className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                      Resultado XML
                    </Label>
                    <Button
                      variant="outline"
                      size="sm"
                      data-testid="button-copy"
                      onClick={copyToClipboard}
                      className={`
                        transition-all duration-300 rounded-lg border-slate-200 dark:border-slate-600
                        ${isCopied 
                          ? "bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-400 border-green-200 dark:border-green-800" 
                          : "text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100"}
                      `}
                    >
                      {isCopied ? (
                        <>
                          <Check className="mr-2 h-4 w-4" />
                          Copiado
                        </>
                      ) : (
                        <>
                          <Copy className="mr-2 h-4 w-4" />
                          Copiar XML
                        </>
                      )}
                    </Button>
                  </div>
                  
                  <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-600 shadow-inner bg-slate-50 dark:bg-slate-900">
                    <Textarea
                      readOnly
                      data-testid="textarea-result"
                      value={xmlResult}
                      className="min-h-[300px] w-full resize-none border-0 bg-transparent p-4 font-mono text-sm leading-relaxed text-slate-600 dark:text-slate-300 focus-visible:ring-0"
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </motion.div>

      <footer className="mt-12 text-center text-sm text-slate-400">
        <p>Herramienta de Conversión Euroliga</p>
      </footer>
    </div>
  );
}
