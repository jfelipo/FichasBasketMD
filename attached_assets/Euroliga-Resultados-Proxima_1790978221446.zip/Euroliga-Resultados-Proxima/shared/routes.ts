import { z } from 'zod';

export const api = {
  convert: {
    method: 'POST' as const,
    path: '/api/convert',
    input: z.object({
      gameday: z.coerce.number().min(1).max(38),
      format: z.enum(['ELBR', 'ELBP']).default('ELBR'),
    }),
    responses: {
      200: z.object({
        xml: z.string(),
      }),
      400: z.object({
        message: z.string(),
      }),
      500: z.object({
        message: z.string(),
      }),
    },
  },
  standings: {
    method: 'POST' as const,
    path: '/api/convert-standings',
    input: z.object({
      text: z.string().trim().min(1, "Pega los datos de la clasificación."),
    }),
    responses: {
      200: z.object({
        xml: z.string(),
      }),
      400: z.object({
        message: z.string(),
      }),
      500: z.object({
        message: z.string(),
      }),
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
