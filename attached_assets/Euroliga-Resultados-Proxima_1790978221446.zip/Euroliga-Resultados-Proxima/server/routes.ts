import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import axios from "axios";
import { XMLParser } from "fast-xml-parser";
import { ZodError } from "zod";
import { generateStandingsXml, parseStandingsText } from "./standings";

interface ScheduleItem {
  gameday: number;
  date: string;
  startime: string;
  hometeam: string;
  awayteam: string;
  gamecode: string;
  played: boolean;
}

interface ResultItem {
  gameday: number;
  date: string;
  time: string;
  hometeam: string;
  awayteam: string;
  homescore: number;
  awayscore: number;
  gamecode: string;
  played: boolean;
}

interface GameData {
  date: string;
  dateObj: Date;
  homeTeam: string;
  awayTeam: string;
  homeScore?: number;
  awayScore?: number;
  time?: string;
  played: boolean;
}

const EURO_LEAGUE_SEASON = "E2026";

const TEAM_NAMES: Record<string, string> = {
  "ANADOLU EFES ISTANBUL": "Anadolu Efes",
  "OLYMPIACOS PIRAEUS": "Olympiacos",
  "MACCABI RAPYD TEL AVIV": "Maccabi Tel Aviv",
  "PANATHINAIKOS AKTOR ATHENS": "Panathinaikos",
  "FC BAYERN MUNICH": "Bayern Múnich",
  "VALENCIA BASKET": "Valencia Basket",
  "EA7 EMPORIO ARMANI MILAN": "Armani Milán",
  "ZALGIRIS KAUNAS": "Zalgiris Kaunas",
  "REAL MADRID": "Real Madrid",
  "AS MONACO": "AS Mónaco",
  "PARIS BASKETBALL": "Paris Basketball",
  "DUBAI BASKETBALL": "Dubai Basketball",
  "FENERBAHCE BEKO ISTANBUL": "Fenerbahçe",
  "KOSNER BASKONIA VITORIA-GASTEIZ": "Kosner Baskonia",
  "VIRTUS BOLOGNA": "Virtus Bolonia",
  "CRVENA ZVEZDA MERIDIANBET BELGRADE": "Estrella Roja",
  "PARTIZAN MOZZART BET BELGRADE": "Partizan",
  "HAPOEL IBI TEL AVIV": "Hapoel Tel Aviv",
  "LDLC ASVEL VILLEURBANNE": "Asvel Villeurbanne",
  "FC BARCELONA": "Barça",
};

function getSpanishTeamName(name: string): string {
  return TEAM_NAMES[name] || name;
}

function formatDateToSpanish(dateStr: string): string {
  const months: Record<string, string> = {
    "Jan": "Enero", "Feb": "Febrero", "Mar": "Marzo", "Apr": "Abril",
    "May": "Mayo", "Jun": "Junio", "Jul": "Julio", "Aug": "Agosto",
    "Sep": "Septiembre", "Oct": "Octubre", "Nov": "Noviembre", "Dec": "Diciembre"
  };
  
  const days: Record<number, string> = {
    0: "Domingo", 1: "Lunes", 2: "Martes", 3: "Miércoles",
    4: "Jueves", 5: "Viernes", 6: "Sábado"
  };
  
  const parsed = new Date(dateStr);
  const dayName = days[parsed.getDay()];
  const dayNum = parsed.getDate();
  const monthParts = dateStr.split(" ");
  const monthName = months[monthParts[0]] || monthParts[0];
  
  return `${dayName}, ${dayNum} ${monthName}`;
}

function formatDateShort(dateStr: string, time: string): string {
  const daysShort: Record<number, string> = {
    0: "dom", 1: "lun", 2: "mar", 3: "mié",
    4: "jue", 5: "vie", 6: "sáb"
  };
  
  const parsed = new Date(dateStr);
  const dayAbbr = daysShort[parsed.getDay()];
  const dayNum = parsed.getDate();
  
  return `${dayAbbr}, ${dayNum} ${time}h`;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post(api.standings.path, async (req, res) => {
    try {
      const { text } = api.standings.input.parse(req.body);
      const teams = parseStandingsText(text);

      if (teams.length === 0) {
        return res.status(400).json({
          message: "No se encontraron equipos. Comprueba el formato de los datos pegados.",
        });
      }

      res.json({ xml: generateStandingsXml(teams) });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: error.issues[0]?.message || "Datos no válidos." });
      }

      console.error("Standings conversion error:", error);
      res.status(500).json({ message: "No se pudo convertir la clasificación." });
    }
  });
  
  app.post(api.convert.path, async (req, res) => {
    try {
      const { gameday, format } = api.convert.input.parse(req.body);
      const parser = new XMLParser();

      // Fetch schedule (for all games including non-played)
      const scheduleResponse = await axios.get(
        `https://api-live.euroleague.net/v1/schedules?competitionCode=E&seasonCode=${EURO_LEAGUE_SEASON}&phaseTypeCode=RS`
      );
      const scheduleData = parser.parse(scheduleResponse.data);
      
      // Fetch results (for played games with scores)
      const resultsResponse = await axios.get(
        `https://api-live.euroleague.net/v1/results?competitionCode=E&seasonCode=${EURO_LEAGUE_SEASON}`
      );
      const resultsData = parser.parse(resultsResponse.data);

      // Extract schedule items for the gameday
      let scheduleItems: ScheduleItem[] = scheduleData.schedule?.item || [];
      if (!Array.isArray(scheduleItems)) scheduleItems = [scheduleItems];
      
      const gamedaySchedule = scheduleItems.filter((item: ScheduleItem) => item.gameday === gameday);
      
      // Extract results
      let resultItems: ResultItem[] = resultsData.results?.game || [];
      if (!Array.isArray(resultItems)) resultItems = [resultItems];
      
      const resultsMap = new Map<string, ResultItem>();
      resultItems.forEach((r: ResultItem) => {
        resultsMap.set(r.gamecode, r);
      });

      // Combine data
      const games: GameData[] = gamedaySchedule.map((sched: ScheduleItem) => {
        const result = resultsMap.get(sched.gamecode);
        const dateObj = new Date(sched.date);
        
        return {
          date: sched.date,
          dateObj,
          homeTeam: getSpanishTeamName(sched.hometeam),
          awayTeam: getSpanishTeamName(sched.awayteam),
          homeScore: result?.homescore,
          awayScore: result?.awayscore,
          time: sched.startime,
          played: sched.played === true || String(sched.played) === "true"
        };
      });

      // Sort games by date (earliest first), then by time (earliest first)
      games.sort((a, b) => {
        const dateDiff = a.dateObj.getTime() - b.dateObj.getTime();
        if (dateDiff !== 0) return dateDiff;
        
        const timeA = a.time || "00:00";
        const timeB = b.time || "00:00";
        return timeA.localeCompare(timeB);
      });

      // Group by date (maintaining order)
      const groupedByDate: { date: string; games: GameData[] }[] = [];
      let currentDate = "";
      
      games.forEach(g => {
        const formattedDate = formatDateToSpanish(g.date);
        if (formattedDate !== currentDate) {
          currentDate = formattedDate;
          groupedByDate.push({ date: formattedDate, games: [] });
        }
        groupedByDate[groupedByDate.length - 1].games.push(g);
      });

      // Construct XML based on format
      let xmlContent: string;
      const today = new Date();
      const dateStr = today.toISOString().split('T')[0];

      if (format === 'ELBP') {
        // ELBP format: próxima jornada with abbreviated dates
        xmlContent = `<table class="proxima_jornada">`;
        xmlContent += `<tr><td class="fecha">La próxima jornada (${gameday})</td></tr>`;
        
        for (const game of games) {
          const dateTime = formatDateShort(game.date, game.time || "00:00");
          xmlContent += `<tr><td>${game.homeTeam}-${game.awayTeam} <ld pattern=""/>${dateTime}</td></tr>`;
        }
        xmlContent += `</table>`;
      } else {
        // ELBR format: resultados with full dates
        xmlContent = `<table class="resultados">`;
        
        for (const dateGroup of groupedByDate) {
          xmlContent += `<tr><td class="fecha">${dateGroup.date}</td></tr>`;
          for (const game of dateGroup.games) {
            let scoreOrTime: string;
            if (game.played && game.homeScore !== undefined && game.awayScore !== undefined) {
              scoreOrTime = `${game.homeScore}-${game.awayScore}`;
            } else {
              scoreOrTime = game.time || "Por definir";
            }
            xmlContent += `<tr><td>${game.homeTeam}-${game.awayTeam}<ld pattern=""/>${scoreOrTime}</td></tr>`;
          }
        }
        xmlContent += `</table>`;
      }

      // Full XML Wrapper
      const fullXml = `<?xml version="1.0" encoding="utf-8"?><?EM-templateName /SysConfig/GODO/Templates/Base/story.xml?>
<!DOCTYPE doc
  SYSTEM "/SysConfig/GODO/Rules/eidosint.dtd">
<doc xml:lang="es"><story><text sourceCIL="4.12.Generated" this="/GODO/MD/Baloncesto/Articulos/${dateStr}/${format}.xml"><content class="ACBX">${xmlContent}</content></text></story></doc>`;

      await storage.logConversion(String(gameday), fullXml, 'success');

      res.json({ xml: fullXml });
    } catch (error) {
      console.error('Conversion error:', error);
      res.status(500).json({ message: "Error al obtener datos de la Euroliga. Inténtelo de nuevo." });
    }
  });

  return httpServer;
}
