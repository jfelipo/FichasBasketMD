interface StandingTeam {
  rank: number;
  name: string;
  wins: string;
  losses: string;
  pointsFor: string;
  pointsAgainst: string;
}

const ID_CHARACTERS =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

export function parseStandingsText(text: string): StandingTeam[] {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  const teams: StandingTeam[] = [];

  for (let i = 0; i < lines.length; i += 1) {
    if (!/^\d+$/.test(lines[i])) continue;

    const rank = Number.parseInt(lines[i], 10);
    const hasLogoLine =
      i + 3 < lines.length && lines[i + 1].toLowerCase().includes("logo");
    const nameLine = hasLogoLine ? lines[i + 2] : lines[i + 1];
    const statsLine = hasLogoLine ? lines[i + 3] : lines[i + 2];
    if (!nameLine || !statsLine) continue;

    const stats = statsLine.split(/\s+/);
    if (stats.length < 6) continue;

    const wins = stats[1];
    const losses = stats[2];
    if (!/^\d+$/.test(wins) || !/^\d+$/.test(losses)) continue;

    teams.push({
      rank,
      name: nameLine,
      wins,
      losses,
      pointsFor: stats[4],
      pointsAgainst: stats[5],
    });
  }

  return teams;
}

function generateId(): string {
  let id = `U${Date.now().toString().slice(-10)}`;
  for (let i = 0; i < 3; i += 1) {
    id += ID_CHARACTERS.charAt(
      Math.floor(Math.random() * ID_CHARACTERS.length),
    );
  }
  return id;
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

export function generateStandingsXml(teams: StandingTeam[]): string {
  const rows = teams
    .map((team) => {
      const placementClass =
        team.rank <= 8 ? "circulo" : team.rank <= 13 ? "cuadrado" : "";
      const classAttribute = placementClass
        ? ` class="${placementClass}"`
        : "";

      return `<tr id="${generateId()}"${classAttribute}><td id="${generateId()}">${escapeXml(team.name)}</td><td id="${generateId()}">${escapeXml(team.wins)}</td><td>${escapeXml(team.losses)}</td><td id="${generateId()}">${escapeXml(team.pointsFor)}</td><td>${escapeXml(team.pointsAgainst)}</td></tr>`;
    })
    .join("\n");

  return `<?xml version="1.0" encoding="utf-8"?><?EM-templateName /SysConfig/GODO/Templates/Base/story.xml?>
<!DOCTYPE doc SYSTEM "/SysConfig/GODO/Rules/eidosint.dtd">
<doc xml:lang="es">
  <story>
    <text sourceCIL="4.12.1882248657" this="/GODO/MD/Importacion/Articulos-autolink/2026-02-26/ELBC.xml">
      <content class="ACBX">
        <table class="clasificacion">
${rows}
        </table>
      </content>
    </text>
  </story>
</doc>`;
}