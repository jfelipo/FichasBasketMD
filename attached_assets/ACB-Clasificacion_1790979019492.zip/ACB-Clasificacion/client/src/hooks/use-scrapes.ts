import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type ScrapeRequest } from "@shared/routes";

export function useScrapes() {
  return useQuery({
    queryKey: [api.scrapes.list.path],
    queryFn: async () => {
      const res = await fetch(api.scrapes.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch scrape history");
      return api.scrapes.list.responses[200].parse(await res.json());
    },
  });
}

export function useScrape(id: number) {
  return useQuery({
    queryKey: [api.scrapes.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.scrapes.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) {
        if (res.status === 404) return null;
        throw new Error("Failed to fetch scrape");
      }
      return api.scrapes.get.responses[200].parse(await res.json());
    },
  });
}

export function useCreateScrape() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: ScrapeRequest) => {
      const res = await fetch(api.scrapes.create.path, {
        method: api.scrapes.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.scrapes.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 500) {
          const error = api.scrapes.create.responses[500].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create scrape");
      }
      
      return api.scrapes.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.scrapes.list.path] });
    },
  });
}
