import { useState } from "react";
import { ScrapeForm } from "@/components/ScrapeForm";
import { HistoryList } from "@/components/HistoryList";
import { XmlViewer } from "@/components/XmlViewer";
import { motion } from "framer-motion";
import { Activity, Clipboard } from "lucide-react";

export default function Home() {
  const [selectedScrape, setSelectedScrape] = useState<any>(null);

  return (
    <div className="min-h-screen bg-background">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[100px] -translate-y-1/2" />
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-blue-500/5 rounded-full blur-[100px] translate-y-1/2" />
      </div>

      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <header className="mb-12 text-center md:text-left">
          <div className="flex items-center gap-3 justify-center md:justify-start mb-4">
            <div className="p-3 bg-gradient-to-br from-primary to-orange-600 rounded-2xl shadow-lg shadow-primary/20 text-white">
              <Activity className="w-8 h-8" />
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold font-display tracking-tight text-foreground">
              ACB <span className="text-primary">XML Generator</span>
            </h1>
          </div>
          <p className="text-muted-foreground text-lg max-w-2xl">
            Pega los datos de la clasificación de ACB.com y genera el XML al instante.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 space-y-8">
            <ScrapeForm onSuccess={setSelectedScrape} />
            <HistoryList 
              onSelect={setSelectedScrape} 
              selectedId={selectedScrape?.id} 
            />
          </div>

          <div className="lg:col-span-7">
            <motion.div
              layout
              className="h-full"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
            >
              {selectedScrape ? (
                <XmlViewer 
                  content={selectedScrape.xmlContent} 
                  filename={`acb-clasificacion-${selectedScrape.temporada}-${selectedScrape.jornada}.xml`} 
                />
              ) : (
                <div className="h-full min-h-[500px] bg-card rounded-2xl border-2 border-dashed border-border flex flex-col items-center justify-center text-center p-12">
                  <div className="w-24 h-24 bg-muted/50 rounded-full flex items-center justify-center mb-6">
                    <Clipboard className="w-10 h-10 text-muted-foreground/50" />
                  </div>
                  <h3 className="text-2xl font-bold font-display text-foreground mb-2">
                    Listo para Generar
                  </h3>
                  <p className="text-muted-foreground max-w-md">
                    Copia la tabla de clasificación de la web de ACB y pégala en el formulario de la izquierda.
                  </p>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
