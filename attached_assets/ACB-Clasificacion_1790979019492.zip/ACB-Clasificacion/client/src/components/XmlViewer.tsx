import { useState } from "react";
import { Download, Copy, Check, FileCode, Maximize2, Minimize2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface XmlViewerProps {
  content: string;
  filename: string;
}

export function XmlViewer({ content, filename }: XmlViewerProps) {
  const [copied, setCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([content], { type: "text/xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <motion.div
      layout
      className={`bg-card rounded-2xl shadow-xl border border-border/50 overflow-hidden flex flex-col ${
        isExpanded ? "fixed inset-4 z-50 h-[calc(100vh-2rem)]" : "h-full min-h-[500px]"
      }`}
    >
      <div className="bg-muted/30 border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500/10 rounded-lg">
            <FileCode className="w-5 h-5 text-blue-500" />
          </div>
          <div>
            <h3 className="font-bold text-foreground">{filename}</h3>
            <p className="text-xs text-muted-foreground font-mono mt-0.5">
              {(new Blob([content]).size / 1024).toFixed(2)} KB
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors"
            title={isExpanded ? "Collapse" : "Expand"}
          >
            {isExpanded ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
          
          <button
            onClick={handleCopy}
            className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors flex items-center gap-2"
            title="Copy to clipboard"
          >
            {copied ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
          </button>
          
          <button
            onClick={handleDownload}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-2 text-sm font-semibold shadow-sm"
          >
            <Download className="w-4 h-4" />
            Download XML
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto bg-[#0d1117] text-gray-300 p-6 font-mono text-sm leading-relaxed custom-scrollbar">
        <pre className="whitespace-pre-wrap break-all">
          <code>{content}</code>
        </pre>
      </div>
      
      {isExpanded && (
        <div className="absolute inset-0 -z-10 bg-background/80 backdrop-blur-sm" aria-hidden="true" />
      )}
    </motion.div>
  );
}
