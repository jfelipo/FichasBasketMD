import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { scrapeRequestSchema, type ScrapeRequest } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ClipboardList } from "lucide-react";

interface ScrapeFormProps {
  onSuccess: (data: any) => void;
}

export function ScrapeForm({ onSuccess }: ScrapeFormProps) {
  const { toast } = useToast();
  const form = useForm<ScrapeRequest>({
    resolver: zodResolver(scrapeRequestSchema),
    defaultValues: {
      temporada: "90",
      jornada: "5898",
      rawContent: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: ScrapeRequest) => {
      const res = await apiRequest("POST", "/api/scrapes", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/scrapes"] });
      toast({
        title: "Éxito",
        description: "XML generado correctamente.",
      });
      form.setValue("rawContent", "");
      onSuccess(data);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Card className="hover-elevate">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ClipboardList className="h-5 w-5" />
          Nueva Clasificación
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="temporada"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Temporada ID</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-temporada" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="jornada"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Jornada ID</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-jornada" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="rawContent"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pegar datos de ACB.com</FormLabel>
                  <FormDescription>
                    Selecciona la tabla en la web, copia (Ctrl+C) y pega aquí (Ctrl+V).
                  </FormDescription>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Ej: 1 Unicaja 17 15 2 1530 1320..."
                      className="min-h-[200px] font-mono text-xs"
                      data-testid="textarea-raw-content"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              className="w-full" 
              disabled={mutation.isPending}
              data-testid="button-submit"
            >
              {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Generar XML
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
