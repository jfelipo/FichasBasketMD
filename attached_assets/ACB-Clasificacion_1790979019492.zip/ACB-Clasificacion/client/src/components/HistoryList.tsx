import { useScrapes } from "@/hooks/use-scrapes";
import { format } from "date-fns";
import { Clock, Download, ChevronRight, FileCode } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface HistoryListProps {
  onSelect: (scrape: any) => void;
  selectedId?: number;
}

export function HistoryList({ onSelect, selectedId }: HistoryListProps) {
  const { data: scrapes, isLoading, isError } = useScrapes();

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-24 bg-muted/50 rounded-xl animate-pulse" />
        ))}
      </div>
    );
  }

  if (isError) {
    return (
      <div className="text-destructive p-4 bg-destructive/10 rounded-xl border border-destructive/20">
        Failed to load history
      </div>
    );
  }

  if (!scrapes || scrapes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-muted-foreground border-2 border-dashed border-border rounded-xl">
        <Clock className="w-12 h-12 mb-4 opacity-20" />
        <p>No scrape history yet</p>
      </div>
    );
  }

  const sortedScrapes = [...scrapes].sort((a, b) => 
    new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
  );

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-bold font-display px-1 flex items-center gap-2">
        <Clock className="w-5 h-5 text-primary" />
        Recent Scrapes
      </h3>
      
      <div className="grid gap-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
        <AnimatePresence initial={false}>
          {sortedScrapes.map((scrape, index) => (
            <motion.div
              key={scrape.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <button
                onClick={() => onSelect(scrape)}
                className={`w-full text-left p-4 rounded-xl border transition-all duration-200 group relative overflow-hidden ${
                  selectedId === scrape.id
                    ? "bg-primary/5 border-primary shadow-md shadow-primary/5"
                    : "bg-card border-border hover:border-primary/50 hover:shadow-lg hover:shadow-black/5"
                }`}
              >
                <div className="flex items-center justify-between relative z-10">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-lg ${
                      selectedId === scrape.id ? "bg-primary text-white" : "bg-muted text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary transition-colors"
                    }`}>
                      <FileCode className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">
                        Season {scrape.temporada} • Round {scrape.jornada}
                      </h4>
                      <p className="text-xs text-muted-foreground mt-1 font-medium">
                        {scrape.createdAt ? format(new Date(scrape.createdAt), "MMM d, yyyy • h:mm a") : "Unknown date"}
                      </p>
                    </div>
                  </div>
                  <ChevronRight className={`w-5 h-5 transition-transform duration-200 ${
                    selectedId === scrape.id ? "text-primary translate-x-1" : "text-muted-foreground group-hover:translate-x-1"
                  }`} />
                </div>
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
