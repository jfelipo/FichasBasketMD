## Packages
framer-motion | Smooth animations for UI elements
prismjs | Syntax highlighting for XML output

## Notes
Scraping endpoint requires 'temporada' and 'jornada' parameters.
XML download should use Blob generation on the client side.
