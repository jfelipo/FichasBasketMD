import { db } from "./db";
import { scrapes, type Scrape, type InsertScrape } from "@shared/schema";
import { desc } from "drizzle-orm";

export interface IStorage {
  createScrape(scrape: InsertScrape): Promise<Scrape>;
  listScrapes(): Promise<Scrape[]>;
}

export class DatabaseStorage implements IStorage {
  async createScrape(insertScrape: InsertScrape): Promise<Scrape> {
    const [scrape] = await db
      .insert(scrapes)
      .values(insertScrape)
      .returning();
    return scrape;
  }

  async listScrapes(): Promise<Scrape[]> {
    return await db
      .select()
      .from(scrapes)
      .orderBy(desc(scrapes.createdAt));
  }
}

export const storage = new DatabaseStorage();
