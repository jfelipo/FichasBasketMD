import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  app.post(api.scrapes.create.path, async (req, res) => {
    try {
      const { temporada, jornada, rawContent } = api.scrapes.create.input.parse(req.body);
      let tableRows = "";

      if (rawContent) {
        console.log("Processing manual content with vertical format support");
        
        // El formato pegado es vertical:
        // 1 (Posición)
        // Nombre Equipo
        // Nombre Equipo (Repetido)
        // PJ (Partidos Jugados)
        // V (Victorias)
        // D (Derrotas)
        // %
        // PF (Puntos Favor)
        // PC (Puntos Contra)
        // +/- (Diferencia)
        // Racha/Últimos...
        
        const lines = rawContent.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        let i = 0;
        
        while (i < lines.length) {
          // Buscamos una línea que sea solo un número (la posición)
          if (/^\d+$/.test(lines[i])) {
            const pos = lines[i];
            
            // Verificamos si hay suficientes líneas después para extraer datos
            // Estructura detectada:
            // i: Pos (1)
            // i+1: Nombre (Real Madrid)
            // i+2: Nombre Repetido (Real Madrid)
            // i+3: PJ (15)
            // i+4: V (13)
            // i+5: D (2)
            // i+6: % (87%)
            // i+7: PF (1.369)
            // i+8: PC (1.238)
            
            if (i + 8 < lines.length) {
              const name = lines[i+1];
              const v = lines[i+4];
              const d = lines[i+5];
              const pf = lines[i+7].replace(/\./g, ''); // Limpiar puntos de miles
              const pc = lines[i+8].replace(/\./g, '');
              
              // Validar que V y D sean números o parezcan estadísticas
              if (name && /^\d+$/.test(v) && /^\d+$/.test(d)) {
                tableRows += `<tr><td>${name}</td><td>${v}</td><td>${d}</td><td>${pf}</td><td>${pc}</td></tr>`;
                // Saltar al siguiente bloque (aproximadamente 12-15 líneas por equipo)
                // Buscamos la siguiente posición numérica
                i += 9; 
                while (i < lines.length && !/^\d+$/.test(lines[i])) {
                  i++;
                }
                continue;
              }
            }
          }
          i++;
        }
        
        // Fallback: Si el parseo vertical falló, intentar el parseo horizontal previo
        if (!tableRows) {
          console.log("Vertical parsing yielded no results, trying horizontal fallback");
          const lines = rawContent.split('\n');
          lines.forEach(line => {
            const parts = line.trim().split(/\s+/);
            if (parts.length >= 5) {
              let numericStartIdx = -1;
              for (let i = parts.length - 1; i >= 0; i--) {
                if (/^\d+$/.test(parts[i].replace(/\./g, ''))) {
                  numericStartIdx = i;
                } else {
                  break;
                }
              }
              if (numericStartIdx > 0) {
                const stats = parts.slice(numericStartIdx);
                const hasPJ = stats.length >= 5;
                const offset = hasPJ ? 1 : 0;
                if (stats.length >= (4 + offset)) {
                  const name = parts.slice(1, numericStartIdx).join(" ") || parts[0];
                  const v = stats[offset];
                  const d = stats[offset + 1];
                  const pf = stats[offset + 2].replace(/\./g, '');
                  const pc = stats[offset + 3].replace(/\./g, '');
                  if (name && /^\d+$/.test(v) && /^\d+$/.test(d)) {
                    tableRows += `<tr><td>${name}</td><td>${v}</td><td>${d}</td><td>${pf}</td><td>${pc}</td></tr>`;
                  }
                }
              }
            }
          });
        }
      }

      const timestamp = Math.floor(Date.now() / 1000);
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      
      const xml = `<?xml version="1.0" encoding="utf-8"?><?EM-templateName /SysConfig/GODO/Templates/Base/story.xml?>
<!DOCTYPE doc
  SYSTEM "/SysConfig/GODO/Rules/eidosint.dtd">
<doc xml:lang="es"><story><text sourceCIL="4.12.${timestamp}" this="/GODO/MD/Baloncesto/Articulos/${dateStr}/ACB-0001.xml"><content class="ACBX"><table class="clasificacion">${tableRows}</table></content></text></story></doc>`;

      const scrape = await storage.createScrape({
        temporada,
        jornada,
        xmlContent: xml
      });

      res.status(201).json(scrape);
    } catch (e) {
      console.error("Processing error:", e);
      res.status(400).json({ message: e instanceof Error ? e.message : "Failed to process content" });
    }
  });

  app.get(api.scrapes.list.path, async (req, res) => {
    const list = await storage.listScrapes();
    res.json(list);
  });

  return httpServer;
}
