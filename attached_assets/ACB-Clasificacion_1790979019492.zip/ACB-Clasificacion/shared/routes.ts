import { z } from 'zod';
import { scrapes, insertScrapeSchema, scrapeRequestSchema } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  scrapes: {
    create: {
      method: 'POST' as const,
      path: '/api/scrapes',
      input: scrapeRequestSchema,
      responses: {
        201: z.custom<typeof scrapes.$inferSelect>(),
        400: errorSchemas.validation,
        500: errorSchemas.internal,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/scrapes',
      responses: {
        200: z.array(z.custom<typeof scrapes.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/scrapes/:id',
      responses: {
        200: z.custom<typeof scrapes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
