import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const scrapes = pgTable("scrapes", {
  id: serial("id").primaryKey(),
  temporada: text("temporada").notNull(),
  jornada: text("jornada").notNull(),
  xmlContent: text("xml_content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertScrapeSchema = createInsertSchema(scrapes).omit({ 
  id: true, 
  createdAt: true 
});

export type Scrape = typeof scrapes.$inferSelect;
export type InsertScrape = z.infer<typeof insertScrapeSchema>;

// Request schema for the scraping operation
export const scrapeRequestSchema = z.object({
  temporada: z.string().default("90"),
  jornada: z.string().default("5898"),
  rawContent: z.string().optional(),
});

export type ScrapeRequest = z.infer<typeof scrapeRequestSchema>;
