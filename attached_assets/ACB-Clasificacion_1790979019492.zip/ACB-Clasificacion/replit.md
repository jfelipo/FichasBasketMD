# ACB XML Generator

## Overview

A web application for generating XML files from ACB (Spanish basketball league) standings data. Users can paste classification data from ACB.com and the system parses it to generate downloadable XML output. The application stores scrape history in a PostgreSQL database for reference.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom basketball-themed color variables (orange primary)
- **Animations**: Framer Motion for smooth UI transitions
- **Build Tool**: Vite with React plugin

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Pattern**: RESTful endpoints defined in shared routes file with Zod validation
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Development**: Hot module replacement via Vite middleware in dev mode

### Data Flow
1. User pastes ACB standings data into textarea
2. Frontend sends POST request to `/api/scrapes` with raw content
3. Backend parses text data, extracts team stats (wins, losses, points for/against)
4. Generates XML table structure and stores in database
5. Returns XML content to frontend for display and download

### Shared Code Pattern
- `shared/schema.ts`: Drizzle table definitions and Zod validation schemas
- `shared/routes.ts`: API route definitions with input/output types
- Both frontend and backend import from shared directory

### Database Schema
Single `scrapes` table storing:
- `temporada`: Season identifier
- `jornada`: Matchday identifier  
- `xmlContent`: Generated XML string
- `createdAt`: Timestamp

## External Dependencies

### Database
- **PostgreSQL**: Primary data store via `DATABASE_URL` environment variable
- **Drizzle Kit**: Database migrations in `./migrations` directory

### Key npm Packages
- `drizzle-orm` / `drizzle-zod`: Type-safe database operations
- `@tanstack/react-query`: Data fetching and caching
- `zod`: Runtime type validation
- `cheerio`: HTML/XML parsing (available but XML generation done manually)
- `framer-motion`: Animation library
- Full shadcn/ui component suite via Radix UI primitives

### Build & Development
- `tsx`: TypeScript execution for server
- `esbuild`: Production server bundling
- `vite`: Frontend build and dev server