import { ReactNode } from "react";
import { Link } from "wouter";
import { LayoutGrid, Github } from "lucide-react";

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background flex flex-col font-sans">
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/20">
              <LayoutGrid className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/80">
              EuroXML
            </span>
          </Link>
          
          <nav className="flex items-center gap-4">
             <a 
               href="https://github.com" 
               target="_blank" 
               rel="noopener noreferrer"
               className="text-muted-foreground hover:text-foreground transition-colors p-2 rounded-md hover:bg-muted"
             >
               <Github className="w-5 h-5" />
             </a>
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8 md:py-12 max-w-5xl">
        {children}
      </main>

      <footer className="border-t border-border py-6 md:py-0">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 md:h-16 text-sm text-muted-foreground">
          <p>© 2024 EuroXML Converter. Herramienta de uso interno.</p>
        </div>
      </footer>
    </div>
  );
}
