## Packages
framer-motion | For smooth entry animations and interaction feedback
lucide-react | For beautiful iconography (already in stack, confirming usage)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  mono: ["JetBrains Mono", "monospace"],
}
