import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import axios from "axios";

interface GameData {
  date: string;
  dateObj: Date;
  homeTeam: string;
  awayTeam: string;
  homeScore?: number;
  awayScore?: number;
  time?: string;
  played: boolean;
}

function formatDateToSpanish(dateStr: string): string {
  const months: Record<string, string> = {
    "01": "Enero", "02": "Febrero", "03": "Marzo", "04": "Abril",
    "05": "Mayo", "06": "Junio", "07": "Julio", "08": "Agosto",
    "09": "Septiembre", "10": "Octubre", "11": "Noviembre", "12": "Diciembre"
  };
  
  const days: Record<number, string> = {
    0: "Domingo", 1: "Lunes", 2: "Martes", 3: "Miércoles",
    4: "Jueves", 5: "Viernes", 6: "Sábado"
  };
  
  const [year, monthKey, dayKey] = dateStr.split("-");
  const parsed = new Date(Date.UTC(Number(year), Number(monthKey) - 1, Number(dayKey)));
  const dayName = days[parsed.getUTCDay()];
  const dayNum = Number(dayKey);
  const monthName = months[monthKey] || monthKey;
  
  return `${dayName}, ${dayNum} ${monthName}`;
}

function formatDateShort(dateStr: string, time: string): string {
  const daysShort: Record<number, string> = {
    0: "dom", 1: "lun", 2: "mar", 3: "mié",
    4: "jue", 5: "vie", 6: "sáb"
  };
  
  const [year, month, day] = dateStr.split("-").map(Number);
  const parsed = new Date(Date.UTC(year, month - 1, day));
  const dayAbbr = daysShort[parsed.getUTCDay()];
  const dayNum = day;
  
  return `${dayAbbr}, ${dayNum} ${time}h`;
}

function getMadridDate(date: Date): string {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Madrid",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function getMadridTime(date: Date): string {
  const parts = new Intl.DateTimeFormat("es-ES", {
    timeZone: "Europe/Madrid",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.hour}:${values.minute}`;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
      app.post(api.convert.path, async (req, res) => {
    try {
      const { gameday, format } = api.convert.input.parse(req.body);

      // For the 2026-2027 season, Jornada 19 starts at matchId 105537.
      // The ACB "week" endpoint returns the round containing the requested match.
      // Match IDs advance by 9 per jornada (9 games per round).
      const baseMatchId = 105537;
      const targetMatchId = baseMatchId + (gameday - 19) * 9;

      const response = await axios.get(
        `https://api2.acb.com/api/matchdata/Menu/matchlist?matchId=${targetMatchId}&format=week`,
        {
          headers: {
            'x-apikey': '0dd94928-6f57-4c08-a3bd-b1b2f092976e',
            'origin': 'https://live.acb.com',
            'referer': 'https://live.acb.com/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
          }
        }
      );

      const data = response.data;
      const matches = Array.isArray(data) ? data : (data.matches || []);

      const games: GameData[] = matches.map((match: any) => {
        const startDT = match.startDateTime || "";
        const dateObj = new Date(startDT);
        const hasValidDate = !Number.isNaN(dateObj.getTime());
        const date = hasValidDate ? getMadridDate(dateObj) : "";
        const time = hasValidDate ? getMadridTime(dateObj) : "Por definir";
        
        return {
          date,
          dateObj,
          homeTeam: match.homeTeam.fullName,
          awayTeam: match.awayTeam.fullName,
          homeScore: match.homeScore,
          awayScore: match.awayScore,
          time,
          played: match.matchStatus === 'FINISHED'
        };
      });

      // Sort games by date (earliest first), then by time (earliest first)
      games.sort((a, b) => {
        const dateDiff = a.dateObj.getTime() - b.dateObj.getTime();
        if (dateDiff !== 0) return dateDiff;
        return (a.time || "").localeCompare(b.time || "");
      });

      // Group by date for results format
      const groupedByDate: { date: string; games: GameData[] }[] = [];
      let currentDate = "";
      
      games.forEach(g => {
        if (!g.date) return;
        const formattedDate = formatDateToSpanish(g.date);
        if (formattedDate !== currentDate) {
          currentDate = formattedDate;
          groupedByDate.push({ date: formattedDate, games: [] });
        }
        groupedByDate[groupedByDate.length - 1].games.push(g);
      });

      // Construct XML
      let xmlContent: string;
      const today = new Date();
      const dateStr = today.toISOString().split('T')[0];

      if (format === 'ELBP') {
        xmlContent = `<table class="proxima_jornada">`;
        xmlContent += `<tr><td class="fecha">La próxima jornada (${gameday})</td></tr>`;
        for (const game of games) {
          const dateTime = formatDateShort(game.date, game.time || "00:00");
          xmlContent += `<tr><td>${game.homeTeam}-${game.awayTeam} <ld pattern=""/>${dateTime}</td></tr>`;
        }
        xmlContent += `</table>`;
      } else {
        xmlContent = `<table class="resultados">`;
        for (const dateGroup of groupedByDate) {
          xmlContent += `<tr><td class="fecha">${dateGroup.date}</td></tr>`;
          for (const game of dateGroup.games) {
            const scoreOrTime = game.played ? `${game.homeScore}-${game.awayScore}` : (game.time || "Por definir");
            xmlContent += `<tr><td>${game.homeTeam}-${game.awayTeam}<ld pattern=""/>${scoreOrTime}</td></tr>`;
          }
        }
        xmlContent += `</table>`;
      }

      const fullXml = `<?xml version="1.0" encoding="utf-8"?><?EM-templateName /SysConfig/GODO/Templates/Base/story.xml?>
<!DOCTYPE doc
  SYSTEM "/SysConfig/GODO/Rules/eidosint.dtd">
<doc xml:lang="es"><story><text sourceCIL="4.12.Generated" this="/GODO/MD/Baloncesto/Articulos/${dateStr}/${format}.xml"><content class="ACBX">${xmlContent}</content></text></story></doc>`;

      await storage.logConversion(String(gameday), fullXml, 'success');
      res.json({ xml: fullXml });
    } catch (error) {
      console.error('Conversion error:', error);
      res.status(500).json({ message: "Error al obtener datos de la ACB. Inténtelo de nuevo." });
    }
  });

  return httpServer;
}
