import { db } from "./db";
import { conversions } from "@shared/schema";

export interface IStorage {
  logConversion(gameday: string, result: string, status: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async logConversion(gameday: string, result: string, status: string): Promise<void> {
    await db
      .insert(conversions)
      .values({ gameday, result, status });
  }
}

export const storage = new DatabaseStorage();
